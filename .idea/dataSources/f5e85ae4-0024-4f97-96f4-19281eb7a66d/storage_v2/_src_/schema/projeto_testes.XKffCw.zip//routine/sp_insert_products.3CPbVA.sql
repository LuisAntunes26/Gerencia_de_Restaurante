create
    definer = root@localhost procedure sp_insert_products(IN nome1 varchar(100), IN preco1 decimal, IN tipo1 varchar(100))
BEGIN
	INSERT INTO produtos (nome, preco, tipo) VALUES (nome1, preco1, tipo1);
END;

