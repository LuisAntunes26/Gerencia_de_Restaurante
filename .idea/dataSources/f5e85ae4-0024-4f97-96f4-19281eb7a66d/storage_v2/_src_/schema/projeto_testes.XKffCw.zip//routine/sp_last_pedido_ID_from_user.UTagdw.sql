create
    definer = root@localhost procedure sp_last_pedido_ID_from_user(IN username varchar(100))
BEGIN
	SELECT id FROM pedido WHERE pedido.username = username ORDER BY id DESC LIMIT 1;
END;

