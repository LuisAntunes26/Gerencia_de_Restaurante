create
    definer = root@localhost procedure sp_update_menu(IN id int, IN nome varchar(100), IN preco decimal(5, 2),
                                                      IN tipo varchar(30))
BEGIN
	UPDATE produtos
	SET produtos.nome = nome,
    produtos.preco = preco,
    produtos.tipo = tipo
	WHERE produtos.id = id;
END;

