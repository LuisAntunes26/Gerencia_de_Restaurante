create
    definer = root@localhost procedure sp_view_produtos_from_pedido(IN input int)
BEGIN
    SELECT pedido.id AS id_pedido, pedido.username, produtos.id AS id_produto, 
    produtos.nome, produtos.preco, produtos.tipo, produtospedido.quantidade
    FROM produtospedido

    INNER JOIN pedido ON pedido.id = id_pedido
    INNER JOIN produtos ON produtos.id = id_produto

    WHERE pedido.id = input;
END;

